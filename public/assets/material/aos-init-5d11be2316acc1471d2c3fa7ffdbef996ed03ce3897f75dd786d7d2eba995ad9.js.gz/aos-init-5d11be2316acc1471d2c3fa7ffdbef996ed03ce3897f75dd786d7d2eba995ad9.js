$(document).on('turbolinks:load', function() {
    "use strict";
    AOS.init();
});
